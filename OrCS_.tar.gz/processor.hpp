// ============================================================================
// ============================================================================
#include <iostream>
#include <fstream>

#define BTB_ASSOC 4
#define BTB_LINES 512
#define MISS_PENALTY 8

//#define MAX_W 256000
#define MAX_H 37
#define MAX_N 2048

#define CACHE_L1_ASSOC 4
#define CACHE_L2_ASSOC 8
#define CACHE_L1_SIZE 64
#define CACHE_L1_LINES 1024
#define CACHE_L2_LINES 16000
#define CACHE_L2_SIZE 1000
#define CACHE_L1_MISS_PENALTY 1
#define CACHE_L2_MISS_PENALTY 4
#define RAM_MISS_PENAULTY 200
#define RAM_SIZE 4000000

// /*************************************************************
//     CACHE L1
// **************************************************************/
// typedef struct cacheLine {
//     uint64_t tag;
//     bool valid;
//     bool dirty;
//     uint64_t lruInfo;
// } cacheLine;

// typedef struct cacheBlock {
//     uint32_t id;
//     cacheLine lines[CACHE_L1_LINES/CACHE_L1_ASSOC];
// } cacheBlock;

// class cacheL1
// {
//     public:
//         cacheBlock blocks[CACHE_L1_ASSOC];
//         uint32_t misses;
//         uint32_t hits;
//         uint64_t cycles;

//         cacheL1();
//         void allocate();
//         bool read();
//         void write();
// };

// /*************************************************************
//     CACHE L2
// **************************************************************/
// typedef struct cacheLine {
//     uint64_t tag;
//     bool valid;
//     bool dirty;
//     uint64_t lruInfo;
// } cacheLine;

// typedef struct cacheBlock {
//     uint32_t id;
//     cacheLine lines[CACHE_L2_LINES/CACHE_L2_ASSOC];
// } cacheBlock;

// class cacheL2
// {
//     public:
//         cacheBlock blocks[CACHE_L2_ASSOC];
//         uint32_t misses;
//         uint32_t hits;
//         uint64_t cycles;

//         cacheL2();
//         void allocate();
//         bool write();
//         void read();
// };

// /*************************************************************
//     RAM
// **************************************************************/
// typedef struct RAMLine {
//     uint32_t tag;
//     uint32_t offset;
//     //uint64_t data;
// } RAMLine;

// typedef struct RAMBlock {
//     uint32_t id;
//     cacheLine lines[RAM_SIZE/(64)];
// } RAMBlock;

// class RAM
// {
//     public:
//         RAMBlock block;
//         uint32_t misses;
//         uint32_t hits;
//         uint64_t cycles;

//         RAM();
//         void allocate();
//         void write();
// };

/*************************************************************
    BTB
**************************************************************/
typedef struct line {
    uint64_t tag; //pc
    uint64_t lruInfo;
    uint64_t targetAddress;
    bool valid;
    bool bht;
    bool bht_ant;
} line;

typedef struct block {
    uint32_t id;
    line lines[BTB_LINES/BTB_ASSOC];
} block;

class BTB {
    public:

    block blocks[BTB_ASSOC];
    uint32_t misses;
    uint32_t hits;

    uint32_t right_address;
    uint32_t wrong_address;

    uint32_t right1;
    uint32_t wrong1;
    uint32_t right2;
    uint32_t wrong2;
    uint64_t cycle1;
    uint64_t cycle2;

    BTB();
    bool search(uint64_t pc, uint32_t *nBlock);
    void insert(opcode_package_t op, bool bht);//line toInsert);
    void allocate();
    void exec(opcode_package_t new_instruction, opcode_package_t next_instruction, bool bht);
};

/*************************************************************
    BRANCH PREDICTOR
*************************************************************/
class bPredictor {
    bool G[MAX_H]; //Shift register global history
    bool SG[MAX_H]; //Speculative shift register global history
    bool H[MAX_H];

    int8_t W[MAX_N][MAX_H]; //Weights table

    uint32_t v[MAX_H]; //Recently used indices
    uint32_t Sv[MAX_H];
    uint32_t R[MAX_H]; //Partial sums of the perceptron
    uint32_t SR[MAX_H]; //Speculative partial sums

    int32_t yout_threshold;
    int8_t max_weight;
    int8_t min_weight;

    void shift_int (uint32_t v[MAX_H], uint32_t x);
    void shift_bool (bool v[MAX_H], bool x);
    int satincdec (int w, bool inc);

    public:
        uint32_t right;
        uint32_t wrong;
        uint64_t cycle;

        bPredictor();
        void allocate();
        bool prediction (uint64_t pc, bool outcome);
        void train (uint64_t i, int8_t yout, bool prediction, bool outcome);

};

class bPredictorPerceptron {
    uint16_t G; //Shift register global history
    uint16_t SG;

    int8_t W[MAX_N][MAX_H]; //Weights table

    uint32_t R[MAX_H]; //Partial sums of the perceptron

    int32_t yout_threshold;

    public:
        uint32_t right;
        uint32_t wrong;
        uint64_t cycle;


        bPredictorPerceptron();
        void allocate();
        bool prediction (uint64_t pc, bool outcome);
        void train (uint64_t i, int8_t yout, bool prediction, bool outcome);

};

/********************************************************************
    PROCESSOR
********************************************************************/
class processor_t {
    public:
        BTB *btb;
        bPredictor *predictor;
        bPredictorPerceptron *perceptron;
        // cacheL1 *cachel1;

        uint64_t cycle;

        // ====================================================================
        /// Methods
        // ====================================================================
        processor_t();
        void allocate();
        void clock();
        void statistics();
};
