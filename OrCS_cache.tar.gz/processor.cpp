#include "simulator.hpp"

/*************************************************
    CACHE L1
**************************************************/
cacheL1::cacheL1()
{

}

void cacheL1::allocate()
{
    for (int i=0; i<(CACHE_L1_ASSOC); i++)
        for (int j=0; j<(CACHE_L1_LINES/CACHE_L1_ASSOC); j++)
        {
            this->blocks[i].lines[j].tag = 0;
            this->blocks[i].lines[j].val = false;
            this->blocks[i].lines[j].dirty = false;
            this->blocks[i].lines[j].lruInfo = 0;
        }

    this->misses=0;
    this->hits=0;
    this->cycles=0;
}

void cacheL1::read(uint64_t address, cacheL2 *l2)
{
    uint64_t tag = (address >> 6);
    uint64_t index = (tag & 1023) % CACHE_L1_LINES;

    this->cycles = this->cycles + CACHE_L1_MISS_PENALTY;

    for (int i=0; i<CACHE_L1_ASSOC; i++)
    {  
        if (tag == this->blocks[i].lines[index].tag 
            && this->blocks[i].lines[index].val == true 
            && this->blocks[i].lines[index].dirty == false)
        {
            this->blocks[i].lines[index].lruInfo = this->cycles;
            this->hits++;
            return;
        }
    }

    this->misses++;
    l2->read(address);
    this->write(address, l2);
}

void cacheL1::write(uint64_t address, cacheL2 *l2)
{
    uint64_t earlierLRU;
    uint32_t earlierI;

    this->cycles = this->cycles + CACHE_L1_MISS_PENALTY;

    uint64_t tag = (address >> 6);
    uint64_t index = (tag & 1023) % CACHE_L1_LINES;

    earlierLRU = 0;
    earlierI = 0;

    for (int i=0; i<CACHE_L1_ASSOC; i++)
    {
        if ((this->blocks[i].lines[index].val == false) || (this->blocks[i].lines[index].dirty == true))
        {
            // this->blocks[i].lines[index].tag = tag;
            // this->blocks[i].lines[index].dirty = false;
            // this->blocks[i].lines[index].lruInfo = this->cycles;
            //this->blocks[i].lines[index].val = true;

            l2->makeDirty(this->blocks[earlierI].lines[index].tag, index);

            return;
        }

        if (this->blocks[i].lines[index].lruInfo < earlierLRU)
        {
            earlierLRU = this->blocks[i].lines[index].lruInfo;
            earlierI = i;
        }
    }

    //Flag dirty=1 on l2 and moves it to ram
    std::cout << "Make dirty \n";
    l2->makeDirty(this->blocks[earlierI].lines[index].tag, index);

    std::cout << "Substitui\n";
    this->blocks[earlierI].lines[index].tag = tag;
    this->blocks[earlierI].lines[index].val = true;
    this->blocks[earlierI].lines[index].dirty = false;
    this->blocks[earlierI].lines[index].lruInfo = this->cycles;

}

/*************************************************
    CACHE L2
**************************************************/
cacheL2::cacheL2()
{

}

void cacheL2::allocate()
{
    for (int i=0; i<(CACHE_L2_ASSOC); i++)
        for (int j=0; j<(CACHE_L2_LINES/CACHE_L2_ASSOC); j++)
        {
            this->blocks[i].lines[j].tag = 0;
            this->blocks[i].lines[j].val = false;
            this->blocks[i].lines[j].dirty = false;
            this->blocks[i].lines[j].lruInfo = 0;
        }

    this->misses=0;
    this->hits=0;
    this->cycles=0;
}

void cacheL2::read(uint64_t address)
{
    uint64_t tag = (address >> 6);
    uint64_t index = (tag & 1023) % CACHE_L2_LINES;

    this->cycles = this->cycles + CACHE_L2_MISS_PENALTY;

    for (int i=0; i<CACHE_L2_ASSOC; i++)
    {  
        if (tag == this->blocks[i].lines[index].tag 
            && this->blocks[i].lines[index].val == 1 
            && this->blocks[i].lines[index].dirty == 0)
        {
            this->blocks[i].lines[index].lruInfo = this->cycles;
            this->hits++;
            return;
        }
    }

    this->misses++;
    this->cycles = this->cycles + RAM_MISS_PENALTY;

    this->write(address);
}

void cacheL2::write(uint64_t address)
{
    uint64_t earlierLRU;
    uint32_t earlierI;

    this->cycles = this->cycles + CACHE_L2_MISS_PENALTY;

    uint64_t tag = (address >> 6);
    uint64_t index = (tag & 1023) % CACHE_L2_LINES;

    earlierLRU = 0;
    earlierI = 0;
    for (int i=0; i<CACHE_L2_ASSOC; i++)
    {
        if (this->blocks[i].lines[index].val == false || this->blocks[i].lines[index].dirty == true)
        {
            this->blocks[i].lines[index].tag = tag;
            this->blocks[i].lines[index].val = true;
            this->blocks[i].lines[index].dirty = false;
            this->blocks[i].lines[index].lruInfo = this->cycles;

            return;
        }

        if (this->blocks[i].lines[index].lruInfo < earlierLRU)
        {
            earlierLRU = this->blocks[i].lines[index].lruInfo;
            earlierI = i;
        }
    }

    this->blocks[earlierI].lines[index].tag = tag;
    this->blocks[earlierI].lines[index].val = true;
    this->blocks[earlierI].lines[index].dirty = false;
    this->blocks[earlierI].lines[index].lruInfo = this->cycles;
}

void cacheL2::makeDirty(uint64_t tag, uint64_t index)
{

    for (int i=0; i<CACHE_L2_ASSOC; i++)
    {  
        if (tag == this->blocks[i].lines[index].tag)
        {
            this->blocks[i].lines[index].dirty = true;
            return;
        }
    }
    return;
}

/*************************************************
    BTB
*************************************************/
void BTB::insert(opcode_package_t op, bool bht)
{
    uint64_t index;
    uint32_t earlierLRU, earlierIndex;

    index = (op.opcode_address >> 2) & 127;
    earlierLRU=this->blocks[0].lines[index].lruInfo;
    earlierIndex = 0;

    for (int i=1; i<BTB_ASSOC; i++)
    {
        if (earlierLRU < this->blocks[i].lines[index].lruInfo)
        {
            earlierLRU = this->blocks[i].lines[index].lruInfo;
            earlierIndex = i;
        }
    }
    this->blocks[earlierIndex].lines[index].tag = op.opcode_address;
    this->blocks[earlierIndex].lines[index].lruInfo = this->cycle1;
    this->blocks[earlierIndex].lines[index].targetAddress = 0;
    this->blocks[earlierIndex].lines[index].valid = true;
    this->blocks[earlierIndex].lines[index].bht_ant = this->blocks[earlierIndex].lines[index].bht;
    this->blocks[earlierIndex].lines[index].bht = bht;
}

bool BTB::search(uint64_t pc, uint32_t *nBlock)
{
    uint64_t index = (pc >> 2) & 127;
    uint32_t i;

    for (i=0; i<BTB_ASSOC; i++)
    {
        if (this->blocks[i].lines[index].tag == pc)
        {
            *nBlock = i;
            return 1;
        }
    }
    return 0;
}

BTB::BTB()
{

}

void BTB::allocate()
{
    this->hits = 0;
    this->misses = 0;
    this->right1 = 0;
    this->wrong1 = 0;
    this->right2 = 0;
    this->wrong2 = 0;
    this->cycle1 = 0;
    this->cycle2 = 0;
    this->right_address = 0;
    this->wrong_address = 0;
    for (int i = 0; i<BTB_ASSOC; i++)
    {
        this->blocks[i].id=i;
        for (int j = 0; j<(BTB_LINES/BTB_ASSOC); j++)
        {
            this->blocks[i].lines[j].tag = 0;
            this->blocks[i].lines[j].lruInfo = 0;
            this->blocks[i].lines[j].targetAddress = 0;
            this->blocks[i].lines[j].valid = false;
            this->blocks[i].lines[j].bht = 0;
            this->blocks[i].lines[j].bht_ant = 0;            
        }
    }
}

void BTB::exec(opcode_package_t new_instruction, opcode_package_t next_instruction, bool bht)
{
    uint32_t nBlock;
    bool prediction;
    uint64_t index = (new_instruction.opcode_address >> 2) & 127;

    //Search the btb, if there is an entry, look at the bht
    if (this->search(new_instruction.opcode_address, &nBlock))
    {
        this->blocks[nBlock].lines[index].lruInfo = this->cycle1;
        this->hits++;

        if (this->blocks[nBlock].lines[index].bht_ant == false)
            prediction = false;
        else
            prediction = true;

        if(this->blocks[nBlock].lines[index].targetAddress == next_instruction.opcode_address)
            this->right_address++;
        else
        {
            this->wrong_address++;
            this->blocks[nBlock].lines[index].targetAddress = next_instruction.opcode_address;
        }

        //Is the prediction right?
        if (prediction == bht)
        {
            this->right2++;
            this->cycle1++;
            this->cycle2++;
        }
        else
        {
            this->cycle1 = this->cycle1+MISS_PENALTY;
            this->cycle2 = this->cycle2+MISS_PENALTY;
            this->wrong2++;
        }

        if (this->blocks[nBlock].lines[index].bht == bht)
            this->right1++;
        else
        {
            this->wrong1++;
            this->blocks[nBlock].lines[index].bht = bht;
        }

        this->blocks[nBlock].lines[index].bht_ant = this->blocks[nBlock].lines[index].bht;
        this->blocks[nBlock].lines[index].bht = bht;

    }
    //If theres no entry, inserts
    else
    {
        this->insert(new_instruction, bht);
        this->misses++;
        this->cycle1 = this->cycle1+MISS_PENALTY;
        this->cycle2 = this->cycle2+MISS_PENALTY;

        if (bht == true)
        {
            this->wrong1++;
            this->wrong2++;
        }
        else
        {
            this->right1++;
            this->right2++;
        }

    }
}

/**********************************************************************
    BRANCH PREDICTOR
**********************************************************************/

bPredictor::bPredictor()
{

}

bPredictorPerceptron::bPredictorPerceptron()
{

}

void bPredictor::allocate()
{
//    this->yout_threshold = (1.93*MAX_H)+14; //Given by the paper
    this->yout_threshold = (int) (2.14 * (MAX_H+1) + 20.58);

    this->max_weight = (1<<(8-1))-1;
    this->min_weight = -(max_weight+1);

    for (uint32_t n=0; n<(MAX_N); n++)
        for (uint32_t h=0; h<(MAX_H); h++)
            this->W[n][h] = 0;

    for (uint32_t h=0; h<MAX_H; h++)
    {
        this->R[h] = 0;
        this->SR[h] = 0;
        this->G[h] = 0;
        this->SG[h] = 0;
        this->H[h] = 0;
        this->v[h] = 0;
        this->Sv[h] = 0;
    }
}

void bPredictorPerceptron::allocate()
{
    this->G = 0;
    this->yout_threshold = (int) (2.14 * (MAX_H+1) + 20.58); //Given by the paper

    for (uint32_t n=0; n<(MAX_N); n++)
        for (uint32_t h=0; h<(MAX_H); h++)
            this->W[n][h] = 0;
}

void bPredictorPerceptron::train(uint64_t i, int8_t yout, bool prediction, bool outcome)
{
    uint16_t g;

    if ((prediction != outcome) || (yout <= this->yout_threshold))
    {
        if (outcome == 1)
            this->W[i][0] = this->W[i][0]+1;
        else
            this->W[i][0] = this->W[i][0]-1;

        for (uint h=1; h<MAX_H; h++)
        {
            g = (G << (16 - h)) >> 15;

            if (outcome == g)
                this->W[i][h] = this->W[i][h]+1;
            else
                this->W[i][h] = this->W[i][h]-1;
        }
    }

    G = (G << 1) | outcome;
}

bool bPredictorPerceptron::prediction(uint64_t pc, bool outcome)
{
    uint64_t i = pc % MAX_N;
    //std::cout << i << '\n';
    int8_t yout = this->W[i][0];
    uint16_t g;

    for (uint h=1; h < MAX_H; h++)
    {
        g = (G << (16 - h)) >> 15;
        //std::cout << "G " << g << '\n';
        if (g == 1)
            yout = yout + W[i][h];
        else
            yout = yout - W[i][h];
    }

    //
    if (yout >= 0)
    {
        this->train(i, yout, true, outcome);
        SG = (G << 1) | true;
        return true;
    }
    this->train(i, yout, false, outcome);
    SG = (G << 1) | false;
    return false;
}


void bPredictor::shift_int (uint32_t v[MAX_H], uint32_t x) 
{
    for (int h=1; h<MAX_H; h++)
        v[h] = v[h-1];
    v[0] = x;
}

    // shift a Boolean into an array; for histories

void bPredictor::shift_bool (bool v[MAX_H], bool x) 
{
    for (int h=2; h<MAX_H; h++)
        v[h] = v[h-1];
    v[1] = x;
}


int bPredictor::satincdec (int w, bool inc) 
{
    if (inc)
    {
        if (w < max_weight)
            w++;
    }
    else
    {
        if (w > min_weight) 
            w--;
    }
    return w;
}

void bPredictor::train(uint64_t i, int8_t yout, bool prediction, bool outcome)
{
    uint32_t k;

   for (uint h=1; h < MAX_H; h++)
   {
        k = MAX_H - h;
        if (outcome == 1)
            this->R[k+1] = this->R[k] + this->W[i][h];
        else
            this->R[k+1] = this->R[k] - this->W[i][h];
    }
    this->R[0] = 0;

    shift_bool(G, outcome);
    shift_int(v, i);

    if (outcome != prediction)
        for (int h=0; h<MAX_H;h++)
        {
            SR[h] = R[h];
            SG[h] = G[h];
            Sv[h] = v[h];
        }

    if ((prediction != outcome) || (yout <= this->yout_threshold))
    {
        if (outcome == 1)
            this->W[i][0] = this->W[i][0]+1;
        else
            this->W[i][0] = this->W[i][0]-1;

        for (uint h=1; h<MAX_H; h++)
        {
            k = this->v[h];

            if (outcome == H[h])
                this->W[k][h] = satincdec(W[k][h], true);
            else
                this->W[k][h] = satincdec(W[k][h], false);

        }
    }

}

bool bPredictor::prediction(uint64_t pc, bool outcome)
{
    uint64_t i;
    int8_t yout;
    uint32_t k;
    bool prediction;

    i = (pc % MAX_N);

    shift_int(Sv, i);

    for (int h=0; h<MAX_H; h++)
    {
        v[h] = Sv[h];
        H[h] = SG[h];
    }

    yout = (this->SR[MAX_H-1] + this->W[i][0]);

    if (yout >= 0)
        prediction = true;
    else 
        prediction = false;

    //Sets speculative R
    for (uint32_t h=1; h<MAX_H; h++)
    {   
        k = MAX_H - h;
        if (prediction == true)
            this->SR[k+1] = this->SR[k] + this->W[i][h];
        else
            this->SR[k+1] = this->SR[k] - this->W[i][h];

    }
    this->SR[0] = 0;
    shift_bool(SG, prediction);

    this->train(i, yout, prediction, outcome);

    return prediction;
}

/*******************************************************************
    PROCESSOR
********************************************************************/

// =====================================================================
processor_t::processor_t() {


}

// =====================================================================
void processor_t::allocate() 
{
    this->btb = new BTB;
    this->predictor = new bPredictor;
    this->perceptron = new bPredictorPerceptron;

    this->L1 = new cacheL1;
    this->L2 = new cacheL2;
}

void processor_t::cache(opcode_package_t new_instruction)
{
    if (new_instruction.is_read)
        this->L1->read(new_instruction.read_address, this->L2);

    if(new_instruction.is_read2)
        this->L1->read(new_instruction.read2_address, this->L2);

    // if (new_instruction.is_write)
    //     this->L1->write(new_instruction.write_address, this->L2);
}

// =====================================================================
void processor_t::clock() 
{
    bool bht;
    bool prediction;

    /// Get the next instruction from the trace
    opcode_package_t new_instruction;
    if (!orcs_engine.trace_reader->trace_fetch(&new_instruction)) {
        /// If EOF
        orcs_engine.simulator_alive = false;
    }
    else
    {
        // BRANCH PREDICTOR
        //is that a branch?
        if ((INSTRUCTION_OPERATION_BRANCH == new_instruction.opcode_operation))
        {
            this->btb->cycle1++;
            this->btb->cycle2++;
            this->perceptron->cycle++;
            this->predictor->cycle++;
            //std::cout << new_instruction.opcode_assembly << '\n';
            //taken or not taken?
            //takes the next instruction (which CANT be another branch) and calculates de address
            opcode_package_t next_instruction;
            if (!orcs_engine.trace_reader->trace_fetch(&next_instruction)) {
                /// If EOF
                orcs_engine.simulator_alive = false;
            }
            else
            {
                //BHT
                if (next_instruction.opcode_address == (new_instruction.opcode_address+new_instruction.opcode_size))
                    bht = false;
                else
                    bht = true;

                //BTB 1 bit
                this->btb->exec(new_instruction, next_instruction, bht);

                //Perceptron fast path
                prediction=this->predictor->prediction(new_instruction.opcode_address, bht);
                if (prediction == true)
                {
                    this->predictor->right++;
                    this->predictor->cycle++;
                }
                else
                {
                    this->predictor->wrong++;
                    this->predictor->cycle = this->predictor->cycle+MISS_PENALTY;
                }

                //Perceptron
                prediction=this->perceptron->prediction(new_instruction.opcode_address, bht);
                if (prediction == true)
                {
                    this->perceptron->right++;
                    this->perceptron->cycle++;
                }
                else
                {
                    this->perceptron->wrong++;
                    this->perceptron->cycle = this->perceptron->cycle+MISS_PENALTY;
                }

                this->cache(next_instruction);

            }
        }
        else
        {
            this->btb->cycle1++;
            this->btb->cycle2++;
            this->perceptron->cycle++;
            this->predictor->cycle++;

            this->cache(new_instruction);
        }
    }
};

// =====================================================================
void processor_t::statistics() {
    ORCS_PRINTF("######################################################\n");
    ORCS_PRINTF("processor_t\n");

    // std::cout << "#############\n";
    // std::cout << "BTB \n";
    // std::cout << "#############\n";
    // std::cout << "BTB misses: " << this->btb->misses << '\n';
    // std::cout << "BTB hits: " << this->btb->hits << '\n';
    // std::cout << "Right Address predictions: " << this->btb->right_address << '\n';
    // std::cout << "Worng Address predictions: " << this->btb->wrong_address << '\n';
    // std::cout << "Total: " << this->btb->right_address + this->btb->wrong_address << '\n';
    // std::cout << (float(this->btb->right_address)/float(this->btb->wrong_address+this->btb->right_address))*100 << '%' << '\n';

    // std::cout << "#############\n";
    // std::cout << "1-BIT predictor\n";
    // std::cout << "#############\n";
    // std::cout << "Cycles: " << this->btb->cycle1 << '\n';
    // std::cout << "Right predictions: " << this->btb->right1 << '\n';
    // std::cout << "Wrong predictions: " << this->btb->wrong1 << '\n';
    // std::cout << "Total: " << this->btb->right1 + this->btb->wrong1 << '\n';
    // std::cout << (float(this->btb->right1)/float(this->btb->wrong1+this->btb->right1))*100 << '%' << '\n';

    // std::cout << "#############\n";
    // std::cout << "2-BIT predictor\n";
    // std::cout << "#############\n";
    // std::cout << "Cycles: " << this->btb->cycle2 << '\n';
    // std::cout << "Right predictions: " << this->btb->right2 << '\n';
    // std::cout << "Wrong predictions: " << this->btb->wrong2 << '\n';
    // std::cout << "Total: " << this->btb->right2 + this->btb->wrong2 << '\n';
    // std::cout << (float(this->btb->right2)/float(this->btb->wrong2+this->btb->right2))*100 << '%' << '\n';

    // std::cout << "#############\n";
    // std::cout << "Perceptron\n" ;
    // std::cout << "#############\n";
    // std::cout << "Cycles: " << this->perceptron->cycle << '\n';
    // std::cout << "Right predictions: " << this->perceptron->right << '\n';
    // std::cout << "Wrong predictions: " << this->perceptron->wrong << '\n';
    // std::cout << "Total: " << this->perceptron->right + this->perceptron->wrong << '\n';
    // std::cout << (float(this->perceptron->right)/float(this->perceptron->wrong+this->perceptron->right))*100 << '%' << '\n';

    // std::cout << "#############\n";
    // std::cout << "Perceptron Fast Path\n" ;
    // std::cout << "#############\n";
    // std::cout << "Cycles: " << this->predictor->cycle << '\n';
    // std::cout << "Right predictions: " << this->predictor->right << '\n';
    // std::cout << "Wrong predictions: " << this->predictor->wrong << '\n';
    // std::cout << "Total: " << this->predictor->right + this->predictor->wrong << '\n';
    // std::cout << (float(this->predictor->right)/float(this->predictor->wrong+this->predictor->right))*100 << '%' << '\n';

    std::cout << "################\n";
    std::cout << "Cache + Fast Path Based Perceptron\n";
    std::cout << "################\n";
    std::cout << "Cycles: " << this->L1->cycles+this->L2->cycles+this->predictor->cycle << "\n";

    std::cout << "################\n";
    std::cout << "Cache L1\n";
    std::cout << "################\n";
    std::cout << "Miss: " << this->L1->misses << "\n";
    std::cout << "Hits: " << this->L1->hits << "\n";
    std::cout << (float(this->L1->hits)/float(this->L1->misses+this->L1->hits))*100 << '%' << '\n';

    std::cout << "################\n";
    std::cout << "Cache L2\n";
    std::cout << "################\n";
    std::cout << "Miss: " << this->L2->misses << "\n";
    std::cout << "Hits: " << this->L2->hits << "\n";
    std::cout << (float(this->L2->hits)/float(this->L2->misses+this->L2->hits))*100 << '%' << '\n';

};
